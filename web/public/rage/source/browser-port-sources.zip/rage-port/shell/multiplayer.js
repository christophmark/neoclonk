'use strict';
// Browser-hosted rooms. Reliable WebRTC carries the original C4Control packets.
// Discovery exchanges connection descriptions; game traffic stays on WebRTC.
(() => {
 const $=id=>document.getElementById(id),lib=window.__scenarioLibrary;
 const protocol='neoclonk-rtc-1',maxPlayers=12,chunkSize=12000,maxFrame=1048576;
 let room=null,engine=false,timer=0,lastBuild=0,lastAck=-1,lastActivity=0,priorFocus=null,sequence=0;
 const pendingFrames=new Map();
 const name=()=>String($('room-name').value||'Clonk captain').replace(/[\r\n\0=\[\]]/g,'').trim().slice(0,24)||'Clonk captain';
 const random=()=>Array.from(crypto.getRandomValues(new Uint32Array(4)),x=>x.toString(16).padStart(8,'0')).join('');
 const encode=value=>{const b=new TextEncoder().encode(JSON.stringify(value));let s='';for(const c of b)s+=String.fromCharCode(c);return btoa(s);};
 const decode=value=>{if(typeof value!=='string'||value.length>60000)throw Error('This invitation is too large.');try{return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(value.trim()),c=>c.charCodeAt(0))));}catch{throw Error('Paste the complete invitation or reply.');}};
 function status(message){$('room-status').textContent=message;}
 function notice(message){status(message);window.__planetHost?.notice(message);const feedback=$('save-feedback');if(engine&&feedback){feedback.hidden=!message;feedback.textContent=message;}}
 const call=(suffix,types=[],args=[],result='number')=>window.Module.ccall('nc_browser_net_'+suffix,result,types,args);
 const nativeStatus=()=>JSON.parse(call('status',[],[],'string'));
 function bytes(suffix,types=[],args=[]){const p=call(suffix,types,args),n=call('size');return p&&n?Module.HEAPU8.slice(p,p+n):null;}
 const to64=b=>btoa(String.fromCharCode(...b));
 function send(peer,message){if(peer.channel?.readyState!=='open')throw Error('A player disconnected. Return to the menu to start a new room.');if(peer.channel.bufferedAmount>2*maxFrame)throw Error('A connection cannot keep up. The round has stopped.');peer.channel.send(typeof message==='string'?message:JSON.stringify(message));}
 function broadcast(message){for(const peer of room.peers.values())if(peer.connected)send(peer,message);}
 function sendBinary(peer,packet){if(peer.channel?.readyState!=='open'||peer.channel.bufferedAmount>2*maxFrame)throw Error('A player connection stopped.');peer.channel.send(packet);}
 function transmit(peer,kind,frame,data){if(data.length>maxFrame)throw Error('The original control packet exceeded the room limit.');const count=Math.ceil(data.length/chunkSize);for(let i=0;i<count;i++){const part=data.subarray(i*chunkSize,(i+1)*chunkSize),packet=new Uint8Array(13+part.length),v=new DataView(packet.buffer);v.setUint8(0,kind);v.setUint32(1,frame);v.setUint16(5,i);v.setUint16(7,count);v.setUint32(9,data.length);packet.set(part,13);sendBinary(peer,packet.buffer);}}
 function stop(error){if(!room||room.error)return;room.error=String(error?.message||error);if(room.host){try{broadcast({type:'error',message:room.error});}catch{}}clearInterval(timer);timer=0;notice(room.error);$('room-start').disabled=true;console.error('[room]',room.error);}
 function roster(){return [{name:room.name,ready:room.ready,index:0},...[...room.peers.values()].filter(p=>p.connected&&p.channel?.readyState==='open').map(p=>({name:p.name,ready:p.ready,index:p.slot}))];}
 function render(){
  if(!room)return;
  const players=room.host?roster():room.players||[];
  const connected=window.__neoclonkDiscovery?.getState().active||room.peers.size>0;
  $('room-mode').hidden=true;$('room-back').hidden=!!connected;
  $('room-crew').hidden=!connected;$('room-actions').hidden=!connected;
  $('room-scenario').hidden=!connected;$('room-scenario').textContent=room.scenario?.title||'';
  $('room-ready-label').hidden=room.host;
  $('room-players').replaceChildren();
  for(const p of players){const li=document.createElement('li'),label=document.createElement('span'),state=document.createElement('span');label.textContent=p.name+(p.index===0?' · host':'');state.textContent=p.ready?'Ready':'Not ready';li.append(label,state);$('room-players').append(li);}
  const canStart=room.host&&!room.started&&players.length>=Math.max(2,room.scenario.minPlayers)&&players.every(p=>p.ready);
  $('room-start').disabled=!canStart;$('room-start').hidden=!room.host;
  $('room-ready').disabled=!!room.started||(!room.host&&!(room.players||[]).length);
  $('room-create-invite').disabled=!!room.started||players.length>=Math.min(maxPlayers,room.scenario?.maxPlayers||maxPlayers);
  $('room-name').disabled=!!room.started;
 }
 function publishRoster(){if(!room?.host)return;room.players=roster();window.__neoclonkDiscovery?.rosterChanged();broadcast({type:'roster',players:room.players});render();}
 function show(){if($('multiplayer-room').hidden)priorFocus=document.activeElement;$('multiplayer-room').hidden=false;$('room-name').focus();}
 function close(){if(!room?.started){disconnect();} $('multiplayer-room').hidden=true;(priorFocus?.isConnected?priorFocus:$('start')).focus();}
 function iceServers(){let value;try{value=JSON.parse($('ice-servers').value||'[]');}catch{throw Error('Connection servers must be a JSON array.');}if(!Array.isArray(value)||value.length>8)throw Error('Use at most eight connection servers.');return value;}
 async function gather(pc){if(pc.iceGatheringState==='complete')return;await new Promise((resolve,reject)=>{const check=()=>{if(pc.iceGatheringState==='complete'){clearTimeout(timeout);pc.removeEventListener('icegatheringstatechange',check);resolve();}};const timeout=setTimeout(()=>{pc.removeEventListener('icegatheringstatechange',check);reject(Error('Connection discovery timed out. Check your connection settings and try again.'));},20000);pc.addEventListener('icegatheringstatechange',check);check();});}
 function peer(slot,servers){const owner=room;const p={slot,pc:new RTCPeerConnection({iceServers:servers||iceServers(),iceTransportPolicy:'all'}),channel:null,connected:false,ready:false,name:'Connecting…',frame:0,engineReady:false,sync:null,parts:new Map()};p.pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(p.pc.connectionState)&&room===owner&&room?.peers.get(slot)===p){if(room.started)stop('A player disconnected. Return to the menu to start a new room.');else{p.connected=false;if(p.discovery){window.__neoclonkDiscovery?.connectionFailed(slot);return;}if(room.host)publishRoster();notice('Connection closed. Create a fresh invitation to try again.');}}};room.peers.set(slot,p);return p;}
 function attach(p,channel){p.channel=channel;channel.binaryType='arraybuffer';channel.onopen=()=>{if(room?.peers.get(p.slot)!==p||p.connected)return;p.connected=true;lastActivity=performance.now();if(!room.host)send(p,{type:'hello',token:room.token,name:room.name,version:lib.version,catalog:lib.catalog.catalogDigest});else notice('Connected. Waiting for your friend’s name.');window.__neoclonkDiscovery?.connected(p.slot);};channel.onclose=()=>{if(room?.peers.get(p.slot)!==p)return;p.connected=false;if(room.started)stop('A player disconnected. Return to the menu to start a new room.');else{if(room.host)publishRoster();if(p.discovery){window.__neoclonkDiscovery?.connectionFailed(p.slot);return;}notice('The other player left. Create a fresh invitation to reconnect.');}};channel.onmessage=event=>{try{if(!room||room.error||room.peers.get(p.slot)!==p)return;lastActivity=performance.now();if(typeof event.data==='string'){if(event.data.length>16000)throw Error('Room message too large.');receive(p,JSON.parse(event.data));}else receiveBytes(p,event.data);}catch(error){stop(error);}};if(channel.readyState==='open')queueMicrotask(channel.onopen);}
 function receiveBytes(p,buffer){if(!engine||!room.started||!(buffer instanceof ArrayBuffer)||buffer.byteLength<14||buffer.byteLength>chunkSize+13)throw Error('Unexpected control packet.');const v=new DataView(buffer),kind=v.getUint8(0),frame=v.getUint32(1),index=v.getUint16(5),count=v.getUint16(7),length=v.getUint32(9),key=kind+':'+frame;
  if((room.host?kind!==1:kind!==2)||!length||length>(room.host?65536:maxFrame)||count!==Math.ceil(length/chunkSize)||index>=count||buffer.byteLength-13!==Math.min(chunkSize,length-index*chunkSize))throw Error('Invalid original control packet.');
  let transfer=p.parts.get(key);if(!transfer){if(p.parts.size>=4)throw Error('Too many incomplete control packets.');transfer={data:new Uint8Array(length),seen:new Set(),created:performance.now()};p.parts.set(key,transfer);}if(transfer.data.length!==length||transfer.seen.has(index))throw Error('Repeated control fragment.');transfer.data.set(new Uint8Array(buffer,13),index*chunkSize);transfer.seen.add(index);if(transfer.seen.size!==count)return;p.parts.delete(key);
  if(room.host){if(call('admit',['number','array','number'],[p.index,transfer.data,length])!==1)throw Error('A player supplied invalid original controls.');}
  else {const st=nativeStatus();if(frame<st.frame||frame>st.frame+2||pendingFrames.has(frame))throw Error('A control frame arrived out of order.');pendingFrames.set(frame,transfer.data);}
 }
 function receive(p,m){if(!m||typeof m.type!=='string')throw Error('Invalid room message.');switch(m.type){
  case 'hello':if(!room.host||room.started||m.token!==p.token||m.version!==lib.version||m.catalog!==lib.catalog.catalogDigest)throw Error('The invitation or game version does not match.');p.name=String(m.name||'Clonk').replace(/[\r\n\0=\[\]]/g,'').slice(0,24);p.ready=false;publishRoster();notice('Your friend is connected. Everyone must select “I’m ready”.');break;
  case 'roster':if(room.host||room.started||!Array.isArray(m.players)||m.players.length>maxPlayers)throw Error('Invalid crew list.');room.players=m.players;render();notice('Connected. Select “I’m ready” when you want to start.');break;
  case 'ready':if(!room.host||room.started)throw Error('Unexpected readiness message.');p.ready=!!m.ready;publishRoster();break;
  case 'name':if(!room.host||room.started)return;p.name=String(m.name||'Clonk').replace(/[\r\n\0=\[\]]/g,'').slice(0,24);publishRoster();break;
  case 'start':if(room.host||room.started||!Array.isArray(m.players)||m.players.length<Math.max(2,room.scenario.minPlayers)||m.players.length>Math.min(maxPlayers,room.scenario.maxPlayers)||!Number.isInteger(m.index)||m.index<1||m.index>=m.players.length||!Number.isInteger(m.seed))throw Error('Invalid round settings.');room.index=m.index;room.seed=m.seed;room.players=m.players;launch().catch(stop);break;
  case 'engine-ready':if(!room.host||!room.started)return;p.engineReady=true;notice('Waiting for all devices to load…');break;
  case 'ack':if(!room.host||!room.started||!Number.isInteger(m.frame)||m.frame<p.frame||m.frame>(engine?nativeStatus().frame+1:0))throw Error('Invalid frame acknowledgment.');p.frame=m.frame;p.sync=typeof m.sync==='string'?m.sync:null;break;
  case 'pause':if(!room.started)return;if(room.host){p.paused=!!m.paused;publishPause();}else{room.paused=!!m.paused;notice(room.paused?'Round paused by a player.':'');}break;
  case 'error':stop('Another player stopped: '+String(m.message||'connection error').slice(0,180));break;
  default:throw Error('Unknown room message.');
 }}
 function publishPause(){lastBuild=performance.now();room.paused=room.localPaused||[...room.peers.values()].some(p=>p.paused);broadcast({type:'pause',paused:room.paused});notice(room.paused?'Round paused by a player.':'');}
 function setPaused(paused){if(!room?.started)return;room.localPaused=!!paused;lastBuild=performance.now();if(room.host)publishPause();else{send([...room.peers.values()][0],{type:'pause',paused:!!paused});notice(paused?'Round paused. Resume from the menu to continue.':'Waiting for the crew…');}}
 function pump(){if(!engine||!room?.started||room.error)return;try{const st=nativeStatus();if(!st.running)return;if(room.host&&[...room.peers.values()].every(p=>p.engineReady)&&!room.paused&&st.frame>0&&performance.now()-lastBuild>120000)throw Error('A device stopped responding. Reload to create a new room.');if(st.paused){Module.ccall('nc_browser_pause','number',['number'],[0]);setPaused(true);} // A native Pause key must pause the whole room.
  if(st.playersJoined){const data=bytes('drain');if(data){if(room.host){if(call('admit',['number','array','number'],[0,data,data.length])!==1)throw Error('The host controls were rejected.');}else transmit([...room.peers.values()][0],1,++sequence,data);}}
  if(!room.host){const p=[...room.peers.values()][0];if(st.frame!==lastAck){lastAck=st.frame;send(p,{type:'ack',frame:st.frame,sync:st.frame>0&&st.frame%120===0?to64(bytes('sync')):null});}const data=pendingFrames.get(st.frame);if(data&&st.acceptedFrame<0){if(call('accept',['number','array','number'],[st.frame,data,data.length])!==1)throw Error('Could not apply the host frame.');pendingFrames.delete(st.frame);}return;}
  const peers=[...room.peers.values()].filter(p=>p.connected);if(!peers.every(p=>p.engineReady)||room.paused||st.acceptedFrame>=0||!peers.every(p=>p.frame===st.frame)||performance.now()-lastBuild<28)return;
  if(st.frame>0&&st.frame%120===0){const sync=to64(bytes('sync'));if(!peers.every(p=>p.sync===sync))throw Error('The original game states diverged. The round has stopped to protect consistency.');room.lastVerifiedFrame=st.frame;}
  const data=bytes('build',['number'],[st.frame]);if(!data)return;for(const p of peers)transmit(p,2,st.frame,data);if(call('accept',['number','array','number'],[st.frame,data,data.length])!==1)throw Error('Could not apply the original host frame.');lastBuild=performance.now();
 }catch(error){try{broadcast({type:'error',message:String(error.message||error)});}catch{}stop(error);}}
 function engineReady(){if(engine||!room?.started)return;engine=true;lastAck=-1;lastActivity=performance.now();if(!room.host)send([...room.peers.values()][0],{type:'engine-ready'});notice('Waiting for all devices to load…');timer=setInterval(pump,10);}
 async function launch(){window.__neoclonkDiscovery?.started();const launchingRoom=room;room.started=true;room.error=null;room.loadingAt=performance.now();setTimeout(()=>{if(room===launchingRoom&&room?.started&&!room.error&&(!engine||(room.host&&[...room.peers.values()].some(p=>!p.engineReady)))){try{broadcast({type:'error',message:'A device could not finish loading the scenario.'});}catch{}stop('A device could not finish loading. Reload to create a new room.');}},180000);render();$('multiplayer-room').hidden=true;$('room-ready').disabled=true;await window.__rageBrowser.startScenario(room.scenario.id,{seed:room.seed,localPlayerIndex:room.index,players:room.players});if(window.__rageBrowser.getState().phase==='error'){broadcast({type:'error',message:'A device could not load the scenario.'});stop('The scenario could not load on this device.');}}
 async function start(){if(!room?.host||$('room-start').disabled)return;for(const [slot,p] of room.peers)if(!p.connected||p.channel?.readyState!=='open'){room.peers.delete(slot);p.channel?.close();p.pc.close();}const peers=[...room.peers.values()];room.players=roster().map((p,i)=>({name:p.name,index:i}));room.index=0;room.seed=crypto.getRandomValues(new Uint32Array(1))[0];peers.forEach((p,i)=>{p.index=i+1;send(p,{type:'start',seed:room.seed,index:p.index,players:room.players});});await launch();}
 function disconnect(){window.__neoclonkDiscovery?.leave();clearInterval(timer);timer=0;engine=false;const previous=room;room=null;pendingFrames.clear();if(previous)for(const p of previous.peers.values()){p.channel?.close();p.pc.close();}}
 function hostOptions(id){
  const chosen=id?lib.find(id):null,engine=chosen?.engine|| (chosen?'rage':$('host-game').value);
  $('host-game').value=engine;
  $('host-scenario').replaceChildren();
  for(const category of lib.catalog.categories){
   const scenarios=lib.catalog.scenarios.filter(s=>s.categoryId===category.id&&(s.engine||'rage')===engine&&s.maxPlayers>=2&&!lib.isBlocked(s));
   if(!scenarios.length)continue;
   const group=document.createElement('optgroup');group.label=category.title;
   for(const scenario of scenarios){const option=document.createElement('option');option.value=scenario.id;option.textContent=scenario.title;group.append(option);}
   $('host-scenario').append(group);
  }
  if(chosen&&[...$('host-scenario').options].some(o=>o.value===id))$('host-scenario').value=id;
  if(room?.host)room.scenario=lib.get($('host-scenario').value);
 }
 async function chooser(){
  await lib.ready;
  if(window.__rageBrowser?.getState().booted){await window.__rageBrowser.restart({lobby:'1'});return;}
  disconnect();$('room-title').textContent='Multiplayer';$('room-name').disabled=false;
  for(const id of ['room-scenario','room-back','discovery-host','discovery-guest','discovery-invite','room-manual','room-crew','room-actions'])$(id).hidden=true;
  $('room-mode').hidden=false;status('');show();
 }
 async function open(host,id){
  await lib.ready;
  if(window.__rageBrowser?.getState().booted){await window.__rageBrowser.restart(host?{scenario:id,host:'1'}:{join:'1'});return;}
  disconnect();if(!window.RTCPeerConnection)throw Error('This browser does not support direct multiplayer connections.');
  room={host,name:name(),scenario:host&&id?lib.get(id):null,peers:new Map(),players:[],ready:host,started:false,index:host?0:null,localPaused:false,paused:false};
  if(host){$('host-game').value=window.__scenarioGallery?.getGame?.()||'rage';hostOptions(id);if(!room.scenario)throw Error('No multiplayer scenarios are available for this game.');}
  $('room-title').textContent=host?'Host a game':'Join a game';
  for(const key of ['host-invite-panel','host-answer-panel'])$(key).hidden=!host;
  $('guest-pair-panel').hidden=host;
  for(const key of ['invite-output','answer-output','answer-input','invite-input'])$(key).value='';
  $('room-ready').checked=host;$('room-ready').disabled=false;
  render();show();window.__neoclonkDiscovery?.open(host);
 }
 $('host-game').onchange=()=>{if(room?.host&&!window.__neoclonkDiscovery?.getState().active&&!room.peers.size){hostOptions();render();}};
 $('host-scenario').onchange=()=>{if(room?.host&&!window.__neoclonkDiscovery?.getState().active&&!room.peers.size){room.scenario=lib.get($('host-scenario').value);render();}};
 async function invite(){if(!room?.host||room.started)return;if(window.__neoclonkDiscovery?.getState().active)throw Error('Leave the online room before creating a manual invitation.');const connected=[...room.peers.values()].filter(p=>p.connected);if(connected.length+1>=Math.min(maxPlayers,room.scenario.maxPlayers))throw Error('This scenario’s crew is full.');for(const [slot,p]of room.peers)if(!p.connected){room.peers.delete(slot);p.pc.close();}const slot=Math.max(0,...room.peers.keys())+1,p=peer(slot);p.token=random();status('Preparing a direct connection…');attach(p,p.pc.createDataChannel('clonk',{ordered:true}));await p.pc.setLocalDescription(await p.pc.createOffer());await gather(p.pc);$('invite-output').value=encode({protocol,version:lib.version,catalog:lib.catalog.catalogDigest,scenario:room.scenario.id,slot,token:p.token,sdp:p.pc.localDescription});status('Send the invitation to your friend, then paste their reply.');render();}
 async function answer(){if(!room||room.host||room.started)return;const offer=decode($('invite-input').value);if(offer.protocol!==protocol||offer.version!==lib.version||offer.catalog!==lib.catalog.catalogDigest)throw Error('Both players need the same Neoclonk version. Reload on both devices.');if(!Number.isInteger(offer.slot)||offer.slot<1||typeof offer.token!=='string'||offer.token.length!==32||offer.sdp?.type!=='offer'||typeof offer.sdp.sdp!=='string')throw Error('Invalid invitation.');for(const p of room.peers.values())p.pc.close();room.peers.clear();room.scenario=lib.get(offer.scenario);room.token=offer.token;room.name=name();$('room-scenario').textContent=room.scenario.title;const p=peer(offer.slot);p.pc.ondatachannel=event=>attach(p,event.channel);status('Preparing your reply…');await p.pc.setRemoteDescription(offer.sdp);await p.pc.setLocalDescription(await p.pc.createAnswer());await gather(p.pc);$('answer-output').value=encode({protocol,slot:offer.slot,token:offer.token,sdp:p.pc.localDescription});status('Send this reply to the host to finish connecting.');render();}
 async function connect(){if(!room?.host||room.started)return;const reply=decode($('answer-input').value),p=room.peers.get(reply.slot);if(reply.protocol!==protocol||!p||reply.token!==p.token||reply.sdp?.type!=='answer'||typeof reply.sdp.sdp!=='string')throw Error('This reply does not match the current invitation.');await p.pc.setRemoteDescription(reply.sdp);status('Connecting directly…');}
 function action(id,fn){$(id).onclick=async()=>{try{await fn();}catch(error){status(error.message||String(error));}};}
 async function copy(id){const input=$(id);if(!input.value)return;try{await navigator.clipboard.writeText(input.value);status('Copied. Send it to your friend.');}catch{input.focus();input.select();if(!document.execCommand('copy'))status('Select and copy this text, then send it to your friend.');else status('Copied. Send it to your friend.');}}
 action('host-room',()=>open(true,window.__scenarioGallery.getSelected().id));action('join-room',chooser);action('room-host-choice',()=>open(true,window.__scenarioGallery?.getSelected()?.id));action('room-join-choice',()=>open(false));action('room-back',chooser);action('room-create-invite',invite);action('room-create-answer',answer);action('room-add-guest',connect);action('room-start',start);action('copy-invite',()=>copy('invite-output'));action('copy-answer',()=>copy('answer-output'));action('room-close',close);action('room-leave',()=>{disconnect();$('multiplayer-room').hidden=true;$('start').focus();});
 $('room-ready').onchange=()=>{if(!room||room.started)return;room.ready=$('room-ready').checked;if(room.host)publishRoster();else{const p=[...room.peers.values()].find(p=>p.connected);if(p)send(p,{type:'ready',ready:room.ready});}};
 $('room-name').onchange=()=>{try{localStorage.setItem('neoclonk.playerName',name());}catch{}if(room&&!room.started){room.name=name();if(room.host)publishRoster();else{const p=[...room.peers.values()].find(p=>p.connected);if(p)send(p,{type:'name',name:room.name});}}};try{$('room-name').value=localStorage.getItem('neoclonk.playerName')||'';}catch{}
 $('multiplayer-room').addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();}else if(event.key==='Tab'){const items=[...$('multiplayer-room').querySelectorAll('button,input,textarea,select,summary')].filter(el=>!el.disabled&&el.getClientRects().length),first=items[0],last=items.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
 window.addEventListener('pagehide',disconnect);
 window.addEventListener('neoclonk-phase',event=>{if(room?.started&&event.detail.phase==='error'){try{broadcast({type:'error',message:'A device could not run the scenario.'});}catch{}stop('The scenario could not run on this device. Reload to start a new room.');}});
 window.__neoclonkRoomTransport={
  status, name, render, getRoom:()=>room,
  remove(slot){const p=room?.peers.get(slot);if(!p)return;room.peers.delete(slot);p.channel?.close();p.pc.close();if(room.host)publishRoster();},
  async offer(slot,token,servers){const owner=room;if(!owner?.host||owner.started)throw Error('The lobby is closed.');this.remove(slot);const p=peer(slot,servers);p.discovery=true;p.token=token;attach(p,p.pc.createDataChannel('clonk',{ordered:true}));await p.pc.setLocalDescription(await p.pc.createOffer());await gather(p.pc);if(room!==owner||owner.peers.get(slot)!==p)throw Error('Connection cancelled.');return {protocol,version:lib.version,catalog:lib.catalog.catalogDigest,scenario:owner.scenario.id,slot,token,sdp:p.pc.localDescription.toJSON()};},
  async answer(offer,servers){const owner=room;if(!owner||owner.host||owner.started)throw Error('The lobby is closed.');if(offer.protocol!==protocol||offer.version!==lib.version||offer.catalog!==lib.catalog.catalogDigest)throw Error('Both players need the same Neoclonk version. Reload both devices.');if(!Number.isInteger(offer.slot)||offer.slot<1||offer.slot>=maxPlayers||typeof offer.token!=='string'||offer.token.length!==32||offer.sdp?.type!=='offer')throw Error('Invalid invitation.');for(const slot of owner.peers.keys())this.remove(slot);owner.scenario=lib.get(offer.scenario);if(!owner.scenario)throw Error('Unknown scenario.');owner.token=offer.token;owner.name=name();$('room-scenario').textContent=owner.scenario.title;const p=peer(offer.slot,servers);p.discovery=true;p.pc.ondatachannel=event=>{if(room===owner&&owner.peers.get(p.slot)===p)attach(p,event.channel);};await p.pc.setRemoteDescription(offer.sdp);await p.pc.setLocalDescription(await p.pc.createAnswer());await gather(p.pc);if(room!==owner||owner.peers.get(p.slot)!==p)throw Error('Connection cancelled.');return {protocol,slot:p.slot,token:offer.token,sdp:p.pc.localDescription.toJSON()};},
  async accept(reply){const owner=room,p=owner?.peers.get(reply.slot);if(!owner?.host||owner.started||!p||reply.protocol!==protocol||reply.token!==p.token||reply.sdp?.type!=='answer')throw Error('This reply no longer matches the invitation.');await p.pc.setRemoteDescription(reply.sdp);},
  connected:slot=>!!room?.peers.get(slot)?.connected&&room.peers.get(slot).channel?.readyState==='open',
  async connectionKind(slot){const p=room?.peers.get(slot);if(!p)return null;const stats=await p.pc.getStats();let pair;stats.forEach(s=>{if(s.type==='transport'&&s.selectedCandidatePairId)pair=stats.get(s.selectedCandidatePairId);});if(!pair)stats.forEach(s=>{if(s.type==='candidate-pair'&&s.state==='succeeded'&&s.nominated)pair=s;});if(!pair)return 'unknown';return [stats.get(pair.localCandidateId),stats.get(pair.remoteCandidateId)].some(c=>c?.candidateType==='relay')?'relay':'direct';}
 };
 window.__neoclonkMultiplayer={chooser:()=>chooser().catch(error=>{show();status(error.message);}),host:id=>open(true,id).catch(error=>{show();status(error.message);}),join:()=>open(false).catch(error=>{show();status(error.message);}),engineReady,disconnect,setPaused,getState:()=>room?{host:room.host,started:room.started,players:room.players,index:room.index,error:room.error,paused:room.paused,localPaused:room.localPaused,lastVerifiedFrame:room.lastVerifiedFrame,engine,connections:[...room.peers.values()].map(p=>({slot:p.slot,connected:p.connected,connection:p.pc.connectionState,channel:p.channel?.readyState,frame:p.frame})),frame:engine?nativeStatus().frame:null}:null};
})();
